# Auto Home Backup v1.0.1

Auto Home Backup script to Dropbox using bash and [Dropbox PHP SDK](https://github.com/dropbox/dropbox-sdk-php). Ideal for full web sites backup from cPanel.

License: [GNU](LICENSE)

## Description

This is a simple script that can be run from a cron job on local Linux or a cPanel web hosting server.

What it does is to archive your home directory and upload that archive file to your Dropbox account regularly. Once the job is done it sends an email with log messages from the execution. If something goes wrong it will include the error log in the email too.

You can make several config files and several cron jobs for them. With that you can backup different parts of your server with different options. Especially useful if you have multiple web sites on a single hosting account with add-on domains.

## Buy Me a Drink

If you like my work and it save you a valuable time and effort, please buy me a drink or two here:

[:coffee: :beers: :cocktail: :tropical_drink: :wine_glass: :tea:](http://4ui.us/tpit)


## Requirements

In order to use the script you need to do the following:
1. Have a Dropbox account
2. Create a Dropbox App
3. Make a Dropbox PHP SDK authentication file - steps are listed here [Dropbox PHP SDK - Get a Dropbox API key](https://github.com/dropbox/dropbox-sdk-php#get-a-dropbox-api-key).

These steps are done only once and you should do them from your local Linux box.

It is preferred to use a Dropbox App authentication, check the [Dropbox PHP SDK - Get a Dropbox API key](https://github.com/dropbox/dropbox-sdk-php#get-a-dropbox-api-key) documentation.

## Setup

Make your own config file or directly edit the config option from the script.

Check examples below.

## Config options

### DROPBOX_UPLOADER_PHP="dropbox_uploader_php.sh"
`dropbox_uploader_php.sh` script location provided along with this script
  

### DROPBOX_UPLOADER_CONFIG_PHP=".dropbox_uploader_php.auth"
`.dropbox_uploader_php.auth` token for more info how to create a auth file check [Dropbox PHP SDK - Get a Dropbox API key](https://github.com/dropbox/dropbox-sdk-php#get-a-dropbox-api-key) documentation
  

### DROPBOX_DST_DIR="/home-backup"
Destination directory on dropbox to be uploaded to. It will be created on first upload under your Dropbox App directory.
  

### BASE_DIR="/home"
Base directory to what the dirs in `DIRS_TO_BACKUP` and `EXCLUDE` are relative.

### DIRS_TO_BACKUP=("user")
Directories array to backup, at least one should be specified.

All directories should be relative to the `BASE_DIR`.

If you want to backup all content of `BASE_DIR` then use: `('.')`

### EXCLUDE=('user/tmp_data' 'tmp' 'cache')
Exclude patterns array, check [man tar](http://www.gnu.org/software/tar/manual/tar.html) for `--exclude` option.

Do not put leading `"/"` in the patters as tar archive do not include them.

If you need to use `?` and `*` in patterns use the single-quoted: `'dir/*'`

### BACKUP_HOST="localhost"
Host name to be used in files and logs.

### BACKUP_NAME="home"
Backup name to be used in files and logs.

### TMP_DIR="/home/user/tmp"
Temp directory to store backup file before upload.

### LOG_DIR="/home/user/log/autohomebackup"
Log directory location.

### MAIL_CONTENT="log"
Mail setup, what would you like to be mailed to you?
 `log` - send only log file.
 `stdout` - will simply output the log to the screen if run manually.
 `quiet` - only send logs if an error occurs to the MAIL_ADDR.

### MAX_ATT_SIZE="4000"
Set the maximum allowed email size in k. (4000 = approx 5MB email).

### MAIL_ADDR="user@domain.com"
Email Address to send mail to?

### PRE_BACKUP="/etc/home-backup-pre"
Command to run before backups.

### POST_BACKUP="/etc/home-backup-post"
Command to run after backups.

## Examples

Examples below are assuming that you uploaded the script files and [Dropbox PHP SDK](https://github.com/dropbox/dropbox-sdk-php) to
`/home/<cpaneluser>/bin`

### Cron Jobs
```
0 1 * * * /home/<cpaneluser>/bin/autohomebackup.sh -c /home/<cpaneluser>/bin/autohomebackup_site-a.conf
0 2 * * * /home/<cpaneluser>/bin/autohomebackup.sh -c /home/<cpaneluser>/bin/autohomebackup_site-b.conf
```

### Config Example Web Site A

`/home/<cpaneluser>/bin/autohomebackup_site-a.conf`

```
DROPBOX_UPLOADER_PHP="/home/<cpaneluser>/bin/dropbox_uploader_php.sh"
DROPBOX_UPLOADER_CONFIG_PHP="/home/<cpaneluser>/bin/.dropbox_uploader_php.auth"
DROPBOX_DST_DIR="/site-a"
BASE_DIR="/home/<cpaneluser>/public_html"
DIRS_TO_BACKUP=("site-a")
EXCLUDE=('cache' 'tmp' 'temp' 'site-a/custom-dir')
BACKUP_HOST="localhost"
BACKUP_NAME="site-a"
TMP_DIR="/home/<cpaneluser>/tmp"
LOG_DIR="/home/<cpaneluser>/logs/autohomebackup"
MAIL_CONTENT="log"
MAX_ATT_SIZE="4000"
MAIL_ADDR="admin@site-a.com"
```

:zap: *The DROPBOX_DST_DIR will be created in the Dropbox account /home/Apps/Dropbox-App-Name/site-a*

:zap: *The paths in EXCLUDE option must be relative to BASE_DIR*

### Config Example Web Site B

`/home/<cpaneluser>/bin/autohomebackup_site-b.conf`

```
DROPBOX_UPLOADER_PHP="/home/<cpaneluser>/bin/dropbox_uploader_php.sh"
DROPBOX_UPLOADER_CONFIG_PHP="/home/<cpaneluser>/bin/.dropbox_uploader_php.auth"
DROPBOX_DST_DIR="/site-b"
BASE_DIR="/home/<cpaneluser>/public_html"
DIRS_TO_BACKUP=("site-b")
EXCLUDE=('cache' 'tmp' 'temp' 'site-b/custom-dir')
BACKUP_HOST="localhost"
BACKUP_NAME="site-b"
TMP_DIR="/home/<cpaneluser>/tmp"
LOG_DIR="/home/<cpaneluser>/logs/autohomebackup"
MAIL_CONTENT="log"
MAX_ATT_SIZE="4000"
MAIL_ADDR="admin@site-a.com"
```

:zap: *The DROPBOX_DST_DIR will be created in the Dropbox account /home/Apps/Dropbox-App-Name/site-b*

:zap: *The paths in EXCLUDE option must be relative to BASE_DIR*

### Notes
Replace the `<cpaneluser>` with your cPanel server user directory name or your local Linux home dir name.

The `/home/<cpaneluser>/bin/.dropbox_uploader_php.auth` from the configs is generated from [Dropbox PHP SDK - Get a Dropbox API key](https://github.com/dropbox/dropbox-sdk-php#get-a-dropbox-api-key) authentication setup.

The backup files that will be uploaded to your Dropbox account from the configs will be located at:
```
/home/Apps/Dropbox-App-Name/site-a/localhost-site-a-2016-03-02_08h55m.tar.gz
/home/Apps/Dropbox-App-Name/site-b/localhost-site-b-2016-03-02_08h55m.tar.gz
```

The `Dropbox-App-Name` will be the one that you configured from [Dropbox PHP SDK - Get a Dropbox API key](https://github.com/dropbox/dropbox-sdk-php#get-a-dropbox-api-key) authentication setup.

## Credits

I used the part of the code from [Auto MySQL Backup](https://sourceforge.net/projects/automysqlbackup/)
